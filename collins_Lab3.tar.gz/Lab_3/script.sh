for ((i=0; i<20; i++))
    do
      GET -dUe http://ec2-52-24-0-1.us-west-2.compute.amazonaws.com:3000/Lab_2
    done